'use client';
import { useEffect, useState, useRef } from 'react';
import { Inter } from 'next/font/google';
import { motion, useScroll, useTransform, useInView } from 'framer-motion';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ContactUs from './components/ContactUs';
import Technology from './components/Technology';
import SolutionsPage from './components/Solution';
import WorkProcess from "./components/WorkProcess";
import WhyChooseUs from "./components/WhyChooseUs";

import WorkPage from './Work/page';
import Testimonialspage from './Testimonials/page';
// import EngagementModelsPage from './EngagementModels/page';


export default function Home() {
  const [activeSection, setActiveSection] = useState<string>('');
  const [loadingPage, setLoadingPage] = useState(true);

  const { scrollY } = useScroll();
  const overlayOpacity = useTransform(scrollY, [0, 300], [0, 0.4]);

  // Simulate page loading
  useEffect(() => {
    const timer = setTimeout(() => setLoadingPage(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  // Scroll listener to update active section
  useEffect(() => {
    const sections = document.querySelectorAll<HTMLElement>('section[id]');
    const handleScroll = () => {
      const scrollY = window.scrollY + 100;
      let current = '';
      sections.forEach((section) => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
          current = section.id;
        }
      });
      setActiveSection(current);
    };
    window.addEventListener('scroll', handleScroll);
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      window.scrollTo({ top: element.offsetTop - 80, behavior: 'smooth' });
    }
  };

  if (loadingPage) {
    return (
      <div className="fixed inset-0 flex flex-col justify-center items-center bg-white z-50" aria-busy="true">
        <img src="/logo.png" alt="Logo" className="w-32 h-32 mb-8 object-contain" />
        <div className="dots-loader flex space-x-2">
          <span className="dot"></span>
          <span className="dot"></span>
          <span className="dot"></span>
        </div>
        <style jsx>{`
          .dot {
            width: 1.5rem;
            height: 1.5rem;
            background-color: #3498db;
            border-radius: 50%;
            display: inline-block;
            animation: blink 1.5s infinite;
          }
          .dot:nth-child(1) { animation-delay: 0s; }
          .dot:nth-child(2) { animation-delay: 0.3s; }
          .dot:nth-child(3) { animation-delay: 0.6s; }
          @keyframes blink {
            0%, 20% { opacity: 0; }
            50% { opacity: 1; }
            100% { opacity: 0; }
          }
        `}</style>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      {/* Global Overlay for Section Transitions */}
      <motion.div
        className="fixed inset-0  pointer-events-none z-40"
        style={{ opacity: overlayOpacity }}
      />

      <Navbar activeSection={activeSection} onNavigate={scrollTo} />

      <main className="relative">
        {/* Hero Section */}
        <SectionWrapper id="hero">
          <section className="relative flex flex-col  -mb-70 md:mb-0  md:mt-10  smd:flex-row items-center justify-center md:justify-start  md:text-left min-h-[80vh] sm:min-h-[90vh] md:min-h-screen px-4 sm:px-10 overflow-hidden">
            <div
              className="absolute inset-0   bg-cover transition-all duration-700"
              style={{
                backgroundImage: "url('/Web_Banner.jpg')",
                backgroundPosition: 'center center',
                backgroundSize: 'contain',
              }}
            />
            <motion.div
              className="relative z-10 max-w-3xl -ml-200 mb-30 flex flex-col gap-5  text-white items-center md:items-start"
              initial={{ opacity: 0, x: -100 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
            <div className="flex flex-col  md:flex-row justify-start items-start w-full md:ml-24 md:mt-32 gap-2 md:gap-4 sm:mb-5 px-4">

              <div className="flex flex-col max-w-2xl text-left space-y-3 font- text-white">
                <p className="text-sm">
                  Experience the Best IT Services in the World.
                </p>

                <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold leading-tight text-white font-hanson">
                  Driving Business <br />
                  Growth with <br />
                  Scalable Digital <br />
                  Solutions!
                </h1>


                <p className="text-sm">
                  We seamlessly blend creative marketing strategies <br /> with novel solutions that help businesses grow,<br />
                  connect, thrive in their niche.
                </p>

                {/* Buttons */}
                <div className="flex flex-col sm:flex-row gap-3 mt-6 w-full sm:w-auto justify-start">
                  <button
                    onClick={() => window.location.replace('/contectus')}
                    className="bg-blue-600 font-bold hover:bg-blue-700 text-white  text-sm px-5 py-2.5 rounded-full shadow-md transition-all font-hanson"
                  >
                    Book a Strategy Call
                  </button>

                  <button
                    onClick={() => scrollTo('technology')}
                    className="bg-white/90 font-bold hover:bg-white text-blue-700 text-sm px-5 py-2.5 rounded-full  shadow-md transition-all font-hanson"
                  >
                    Check Our Expertise
                  </button>
                </div>
              </div>
            </div>


            </motion.div>
          </section>
        </SectionWrapper>

        {/* Technology Section */}
        <SectionWrapper id="technology">
          <Technology />
        </SectionWrapper>

        {/* Solutions Section */}
        <SectionWrapper id="solutions">
          <div className="bg-blue-50">
            <SolutionsPage />
          </div>
        </SectionWrapper>

        <WorkProcess/>
        <WhyChooseUs />

        {/* Engagement Models
        <SectionWrapper id="engagement-models">
            <EngagementModelsPage />
        </SectionWrapper> */}

        {/* Testimonials */}
        <SectionWrapper id="testimonials">
          <Testimonialspage />
        </SectionWrapper>

        {/* Work */}
        <SectionWrapper id="work">
          <div className="max-w-6xl mx-auto">
            <WorkPage />
          </div>
        </SectionWrapper>

        {/* Contact */}
        <SectionWrapper id="contactus">
          <div>
            <ContactUs />
          </div>
        </SectionWrapper>
      </main>

      <Footer />
    </div>
  );
}

// Reusable Section Wrapper with Slide-In Animation
function SectionWrapper({ children, id }: { children: React.ReactNode; id: string }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <motion.section
      ref={ref}
      id={id}
      initial={{ opacity: 0, y: 80 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 80 }}
      transition={{ duration: 0.7, ease: "easeOut" }}
      className="relative"
    >
      {/* Optional: Add subtle overlay per section */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/5 to-transparent pointer-events-none" />
      <div className="relative z-10">
        {children}
      </div>
    </motion.section>
  );
}