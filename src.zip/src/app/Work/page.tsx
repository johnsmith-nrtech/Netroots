"use client";
import React, { useState, useEffect } from "react";
import Image from "next/image";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";


export default function WorkPage() {
  const [loading, setLoading] = useState(true);

  const industries = [
    { title: "Industry & Manufacturing", imgSrc: "/Industry.jpg" },
    { title: "Transportation & Logistics", imgSrc: "/Logistics.jpg" },
    { title: "Healthcare", imgSrc: "/health.jpg" },
    { title: "Banks & Insurance", imgSrc: "/bank.jpg" },
  ];

  const clients = [
    "/clients/hanif.png",
    "/clients/iasp.png",
    "/clients/ivy.png",
    "/clients/jnj.png",
    "/clients/pain.png",
  ];

  // Simulate loading
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  // Slick slider settings
  const settings = {
    dots: true,
    infinite: true,
    speed: 700,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    responsive: [
      {
        breakpoint: 1024,
        settings: { slidesToShow: 2 },
      },
      {
        breakpoint: 640,
        settings: { slidesToShow: 1 },
      },
    ],
  };

  const IndustryCard = ({ title, imgSrc }) => (
    <div className="px-2">
      <div className="flex flex-col items-center">
        <Image
          src={imgSrc}
          alt={title}
          width={400}
          height={256}
          className="object-cover w-full max-w-md h-64 rounded-lg shadow-md"
        />
        <p className="mt-4 text-center text-gray-700 font-medium">{title}</p>
      </div>
    </div>
  );

  return (
    <div className="py-12 px-6 md:px-16">
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="loader ease-linear rounded-full border-8 border-t-8 border-gray-200 h-16 w-16"></div>
        </div>
      ) : (
        <>
          {/* Header */}
          <div className="mb-12 text-center lg:text-left">
            <h2 className="text-lg uppercase text-gray-500 mb-2 tracking-wide">
              WHO WE WORK WITH
            </h2>
            <h1 className="text-3xl lg:text-4xl font-bold mb-8">
              Explore Netroots Technologies by Industry
            </h1>
          </div>

          {/* Industries Slider */}
          <Slider {...settings}>
            {industries.map((industry, i) => (
              <IndustryCard key={i} title={industry.title} imgSrc={industry.imgSrc} />
            ))}
          </Slider>

          {/* Clients Marquee */}
          <h3 className="text-xl font-semibold text-center my-8">
            Some of Our Clients
          </h3>
          <div className="w-full overflow-hidden">
            <div
              className="inline-block whitespace-nowrap animate-marquee space-x-16"
              style={{ animationDuration: "10s" }}
            >
              {[...clients, ...clients].map((clientSrc, i) => (
                <Image
                  key={i}
                  src={clientSrc}
                  alt={`Client logo ${i + 1}`}
                  width={100}
                  height={64}
                  className="inline-block opacity-70 hover:opacity-100 transition-opacity"
                />
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
