"use client";
import { useEffect, useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import ContactUs from '../components/ContactUs';
import React from "react";
import Image from "next/image";

export default function IndustriesPage() {
  const [loadingPage, setLoadingPage] = useState(true);

  // Simulate page loading
  useEffect(() => {
    const timer = setTimeout(() => setLoadingPage(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  const industries = [
    {
      title: "Industry & Manufacturing",
      imgSrc: "/Industry.jpg",
      description: "Innovative solutions to optimize production and operations.",
    },
    {
      title: "Transportation & Logistics",
      imgSrc: "/Logistics.jpg",
      description: "Efficient logistics and transport solutions for your business.",
    },
    {
      title: "Healthcare",
      imgSrc: "/health.jpg",
      description: "Advanced healthcare technology to improve patient care.",
    },
    {
      title: "Banks & Insurance",
      imgSrc: "/bank.jpg",
      description: "Secure and reliable banking and insurance services.",
    },
    {
      title: "Retail & E-commerce",
      imgSrc: "/retail.jpg",
      description: "Transforming retail experiences with innovative tech.",
    },
    {
      title: "Education & eLearning",
      imgSrc: "/education.jpg",
      description: "Empowering learning through modern digital solutions.",
    },
    {
      title: "Telecom & IT Services",
      imgSrc: "/telecom.jpg",
      description: "Connecting people and businesses through IT excellence.",
    },
  ];

  const IndustryCard = ({ title, imgSrc, description }) => (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform duration-300 hover:-translate-y-4 flex flex-col">
      <Image
        src={imgSrc}
        alt={title}
        width={400}
        height={256}
        className="object-cover w-full h-64"
      />
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="text-lg font-semibold text-gray-800 text-center mb-2">{title}</h3>
        <p className="text-gray-600 text-sm text-center mb-4">{description}</p>

        {/* Horizontal line */}
        <hr className="border-gray-300 my-3" />

        {/* Button */}
        <button className="mt-auto bg-gradient-to-r from-indigo-300 to-blue-200 text-gray-600 font-semibold px-5 py-2 rounded-lg shadow-md hover:from-indigo-400 hover:to-blue-300 hover:translate-y-[-2px] transition-all duration-300">
          Read More
        </button>
      </div>
    </div>
  );
if (loadingPage) {
  return (
    <div className="fixed inset-0 flex flex-col justify-center items-center bg-white z-50" aria-busy="true">
      <img src="/logo.png" alt="Logo" className="w-32 h-32 mb-8 object-contain" />
      <div className="dots-loader flex space-x-2">
        <span className="dot"></span>
        <span className="dot"></span>
        <span className="dot"></span>
      </div>
      <style jsx>{`
        .dot {
          width: 1.5rem;
          height: 1.5rem;
          background-color: #3498db;
          border-radius: 50%;
          display: inline-block;
          animation: blink 1.5s infinite;
        }
        .dot:nth-child(1) { animation-delay: 0s; }
        .dot:nth-child(2) { animation-delay: 0.3s; }
        .dot:nth-child(3) { animation-delay: 0.6s; }
        @keyframes blink {
          0%, 20% { opacity: 0; }
          50% { opacity: 1; }
          100% { opacity: 0; }
        }
      `}</style>
    </div>
  );
}

  return (
    <main>
      <div className="min-h-screen mt-20 bg-gray-50 py-12 px-6 md:px-16">
        <Navbar />
        {/* Header */}
        <div className="mb-12 text-center">
          <h2 className="text-lg uppercase text-gray-500 mb-2 tracking-wide">
            INDUSTRIES WE SERVE
          </h2>
          <h1 className="text-3xl lg:text-4xl font-bold mb-8">
            Explore Netroots Technologies by Industry
          </h1>
        </div>

        {/* Industries Grid */}
        <div className="grid gap-8 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {industries.map((industry, i) => (
            <IndustryCard
              key={i}
              title={industry.title}
              imgSrc={industry.imgSrc}
              description={industry.description}
            />
          ))}
        </div>
      </div>
      {/* ContactUS */}
      <ContactUs />
      {/* Footer */}
      <Footer />
    </main>
  );
}
