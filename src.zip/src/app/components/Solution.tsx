import React, { useState } from "react";

import { FaLaptopCode, FaMobileAlt, FaPencilRuler } from "react-icons/fa";

const services = [
  {
    id: 1,
    title: "Website Development",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.",
    icon: (
      <div className="flex gap-1 text-white">
        <FaLaptopCode size={20} />
      </div>
    ),
    active: false,
  },
  {
    id: 2,
    title: "Mobile App Development",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.",
    icon: (
      <div className="flex gap-1 text-white">
        <FaMobileAlt size={20} />
      </div>
    ),
    active: false,
  },
  {
    id: 3,
    title: "UI/UX Design",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.",
    icon: (
      <div className="flex gap-1 text-white">
        <FaPencilRuler size={20} />
      </div>
    ),
    active: false,
  },
];


export default function Services() {
  const [hoveredId, setHoveredId] = useState<number | null>(null);

  return (
    <section className="max-w-6xl text-left mx-auto px-6 py-12">
      <p className=" font-semibold mb-2"><span className="text-teal-500">//</span> Our Services</p>
      <h2 className="text-3xl font-bold mb-1">
        Services We Provide to{" "}<br/>
        <span className="text-blue-600">Elevate Your Business</span>
      </h2>
      <div className="text-right -mt-10 mb-18">
        <button className="bg-blue-600 mr-10  text-white px-4 py-1 rounded-full text-sm hover:bg-blue-700 transition">
          View all Services
        </button>
      </div>

      <div className="flex flex-wrap  ml-20 gap-6">
        {services.map(({ id, title, description, icon }) => {
          const isActive = hoveredId === id;

          return (
            <div
              key={id}
              onMouseEnter={() => setHoveredId(id)}
              onMouseLeave={() => setHoveredId(null)}
              className={`flex flex-col items-start gap-4 bg-white rounded-xl p-6 shadow-md w-72 transition-all duration-300 cursor-pointer
                ${isActive
                  ? "border border-blue-600 border-b-4 border-b-blue-800 shadow-lg scale-105"
                  : "border border-transparent hover:shadow-lg hover:scale-105"
                }`}
            >
              <div
                className={`bg-blue-600 p-3 rounded-lg flex items-center justify-center transition-all duration-300 ${
                  isActive ? "mb-2" : "mb-4"
                }`}
                style={{ width: 40, height: 40 }}
              >
                {icon}
              </div>
              <h3
                className={`font-semibold text-lg transition-all duration-300 ${
                  isActive ? "text-blue-600 mb-1" : "text-gray-800 mb-2"
                }`}
              >
                {title}
              </h3>
              <p className="text-gray-600 text-sm">{description}</p>
            </div>
          );
        })}
      </div>
    </section>
  );
}
