import { FaDollarSign, FaUsers, FaTrophy, FaHistory } from "react-icons/fa";
import Image from "next/image";
import { Inter } from "next/font/google";

// Load Inter font
const inter = Inter({ subsets: ["latin"], weight: ["400", "500", "600", "700"] });

export default function WhyChooseUs() {
  return (
    <section className={`bg-black text-white py-16 px-6 md:px-16 ${inter.className}`}>
      <div className="max-w-7xl mx-auto relative">
        {/* Get A Quote button - top right */}
        <div className="absolute top-10 right-5">
          <a
            href="#"
            className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-5 py-2 rounded-full transition"
          >
            Get A Quote
          </a>
        </div>

        {/* Section Header */}
        <div className="mb-12">
          <p className="text-sm">
            <span className="text-teal-500">//</span> Why Choose Us
          </p>
          <h2 className="text-3xl md:text-4xl font-samibold mt-2">
            Why Trust Us for<br />Your IT Needs?
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left: Image */}
          <div className="relative rounded-lg overflow-hidden">
            <Image
              src="/team-meeting.jpg"
              alt="Team high five"
              width={600}
              height={400}
              className="object-cover w-full h-full"
            />
          </div>

          {/* Right: Content */}
          <div className="space-y-8">
            <div className="grid sm:grid-cols-2 gap-8">
              {/* Affordable Price */}
              <div className="flex flex-col space-y-2">
                <FaDollarSign className="text-5xl " />
                <h3 className="font-semibold text-lg">Affordable Price</h3>
                <p className="text-gray-400 text-sm">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                </p>
              </div>

              {/* Professional Team */}
              <div className="flex flex-col space-y-2">
                <FaUsers className="text-5xl" />
                <h3 className="font-semibold text-lg">Professional Team</h3>
                <p className="text-gray-400 text-sm">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                </p>
              </div>

              {/* 18+ Years Experience */}
              <div className="flex flex-col space-y-2">
                <FaHistory className="text-5xl " />
                <h3 className="font-semibold text-lg">18+ Years Experience</h3>
                <p className="text-gray-400 text-sm">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                </p>
              </div>

              {/* Award Winning */}
              <div className="flex flex-col space-y-2">
                <FaTrophy className="text-5xl " />
                <h3 className="font-semibold text-lg">Award Winning</h3>
                <p className="text-gray-400 text-sm">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
