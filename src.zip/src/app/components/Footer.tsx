export default function Footer() {
  return (
    <footer className="relative bg-black text-white overflow-hidden">
      {/* Decorative Background Dots (Right Side) */}
      <div className="relative z-10 pt-10 max-w-7xl mx-auto flex flex-wrap md:flex-nowrap justify-between gap-10 px-4 sm:px-6 lg:px-8">
        {/* LEFT COLUMN */}
        <div className="w-full md:w-3/4 flex flex-col gap-10">
          {/* Solutions Section */}
          <div className="footer-section">
            <h3 className="text-lg mb-4 font-semibold">Solutions</h3>
            <div className="flex flex-wrap gap-x-10 gap-y-4">
              <ul className="space-y-2 text-sm text-gray-300 w-1/2 sm:w-40">
                <li><a href="#" className="hover:text-white">Rank #1 on Google</a></li>
                <li><a href="#" className="hover:text-white">Website Design & Development</a></li>
                <li><a href="#" className="hover:text-white">Design Alchemy</a></li>
                <li><a href="#" className="hover:text-white">Community Management</a></li>
              </ul>
              <ul className="space-y-2 text-sm text-gray-300 w-1/2 sm:w-40">
                <li><a href="#" className="hover:text-white">Performance Marketing</a></li>
                <li><a href="#" className="hover:text-white">Brand Strategy Development</a></li>
                <li><a href="#" className="hover:text-white">E-commerce Solutions</a></li>
                <li><a href="#" className="hover:text-white">Content Marketing</a></li>
              </ul>
            </div>
          </div>

          {/* Company Section */}
          <div className="footer-section">
            <h3 className="text-lg mb-4 font-semibold">Company</h3>
            <div className="flex flex-wrap gap-x-10 gap-y-4">
              <ul className="space-y-2 text-sm text-gray-300 w-1/2 sm:w-40">
                <li><a href="#" className="hover:text-white">Why us</a></li>
                <li><a href="#" className="hover:text-white">Careers</a></li>
              </ul>
              <ul className="space-y-2 text-sm text-gray-300 w-1/2 sm:w-40">
                <li><a href="#" className="hover:text-white">Blog</a></li>
                <li><a href="#" className="hover:text-white">FAQ</a></li>
              </ul>
            </div>
          </div>

          {/* Social Icons + Newsletter */}
          <div>
            <div className="flex space-x-4 mt-4 mb-6 justify-start">
              {[
                { src: 'https://cdn-icons-png.flaticon.com/512/733/733547.png', alt: 'Facebook' },
                { src: 'https://cdn-icons-png.flaticon.com/512/733/733558.png', alt: 'Twitter' },
                { src: 'https://cdn-icons-png.flaticon.com/512/733/733561.png', alt: 'LinkedIn' },
                { src: 'https://cdn-icons-png.flaticon.com/512/1384/1384060.png', alt: 'YouTube' },
              ].map(({ src, alt }, idx) => (
                <a key={idx} href="#" aria-label={alt}>
                  <img src={src} alt={alt} className="w-5 hover:opacity-80 transition-opacity" />
                </a>
              ))}
            </div>

            {/* Newsletter Section */}
            <div className="max-w-md">
              <form className="space-y-3">
                <input
                  type="email"
                  placeholder="Don't miss out updates"
                  aria-label="Email Address"
                  className="w-full px-4 py-2 bg-gray-900 text-white border border-gray-700 rounded placeholder-gray-400"
                />
                <label className="flex items-start text-sm text-gray-300">
                  <input type="checkbox" className="mt-1 mr-2" />
                  <span>I agree to the Privacy Policy and give my permission to process my personal data for the purposes specified in the Privacy Policy.</span>
                </label>
                <button
                  type="submit"
                  className="w-full bg-blue-700 hover:bg-blue-800 transition-colors text-white px-5 py-2 rounded"
                >
                  Send
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN */}
        <div className="relative md:absolute md:inset-y-0 md:right-0 w-full md:w-1/2 mt-10 md:mt-0">
          {/* Decorative Background Dots */}
          <div className="absolute inset-0 bg-[radial-gradient(#ccc_4px,transparent_4px)] bg-[length:60px_60px] opacity-10 z-0 pointer-events-none" />

          <div className="footer-section mt-25 w-full flex flex-col items-center text-center z-10 relative px-4">
            <img
              src="logo-nrt-02.png"
              alt="Netroots Technologies Logo"
              className="w-40 mb-4 md:w-68"
            />
            <h3 className="text-lg font-semibold">Netroots Technologies</h3>
            <button className="mt-4 bg-blue-700 hover:bg-blue-800 transition-colors text-white px-6 py-2 rounded">
              Schedule Consultation
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="relative z-10 bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col md:flex-row justify-between items-center text-sm text-gray-700">
          <p>&copy; {new Date().getFullYear()} Netroots Technologies. All Rights Reserved.</p>
          <div className="flex space-x-4 mt-2 md:mt-0 flex-wrap justify-center">
            <a href="#" className="hover:text-black transition-colors">Privacy Policy</a>
            <span>|</span>
            <a href="#" className="hover:text-black transition-colors">Terms & Conditions</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
