import { useState, useEffect } from "react";
import { FaStar, FaStarHalfAlt } from "react-icons/fa";

const tabs = [
  "Mobile",
  "Front-End",
  "Web",
  "Back-End",
  "Dev&CloudOps",
  "AI/ML",
  "UI/UX",
  "QA&Testing",
  "Blockchain",
] as const;

type TabType = (typeof tabs)[number];

interface TechItem {
  name: string;
  src: string;
}

const tabContent: Record<
  TabType,
  { title: string; description: string; techs: TechItem[] }
> = {
  Mobile: {
    title: "Mobile Development",
    description:
      "Our Mobile Development team builds robust, cross-platform mobile apps with modern frameworks and tools to deliver smooth user experiences.",
    techs: [
      {
        name: "React Native",
        src: "https://upload.wikimedia.org/wikipedia/commons/a/a7/React-icon.svg",
      },
      {
        name: "Flutter",
        src: "https://upload.wikimedia.org/wikipedia/commons/1/17/Google-flutter-logo.png",
      },
      {
        name: "Swift",
        src: "https://upload.wikimedia.org/wikipedia/commons/9/9d/Swift_logo.svg",
      },
      {
        name: "Kotlin",
        src: "https://upload.wikimedia.org/wikipedia/commons/7/74/Kotlin_Icon.png",
      },
      {
        name: "Xamarin",
        src: "https://upload.wikimedia.org/wikipedia/commons/1/1e/Xamarin-logo.svg",
      },
    ],
  },
  "Front-End": {
    title: "Front-End Development",
    description:
      "Our Front-End team creates visually appealing, responsive, and user-friendly websites using modern frameworks.",
    techs: [
      {
        name: "React",
        src: "https://upload.wikimedia.org/wikipedia/commons/a/a7/React-icon.svg",
      },
      {
        name: "Vue.js",
        src: "https://upload.wikimedia.org/wikipedia/commons/9/95/Vue.js_Logo_2.svg",
      },
      {
        name: "Angular",
        src: "https://upload.wikimedia.org/wikipedia/commons/c/cf/Angular_full_color_logo.svg",
      },
      {
        name: "Tailwind CSS",
        src: "https://upload.wikimedia.org/wikipedia/commons/d/d5/Tailwind_CSS_Logo.svg",
      },
      {
        name: "Sass",
        src: "https://upload.wikimedia.org/wikipedia/commons/9/96/Sass_Logo_Color.svg",
      },
      {
        name: "Next.js",
        src: "https://upload.wikimedia.org/wikipedia/commons/8/8e/Nextjs-logo.svg",
      },
    ],
  },
  Web: {
    title: "Web Development",
    description: "Dynamic full-stack web apps with modern stacks.",
    techs: [
      {
        name: "Node.js",
        src: "https://upload.wikimedia.org/wikipedia/commons/d/d9/Node.js_logo.svg",
      },
      {
        name: "React.js",
        src: "https://upload.wikimedia.org/wikipedia/commons/a/a7/React-icon.svg",
      },
      {
        name: "Express.js",
        src: "https://upload.wikimedia.org/wikipedia/commons/6/64/Expressjs.png",
      },
      {
        name: "MongoDB",
        src: "https://upload.wikimedia.org/wikipedia/commons/9/93/MongoDB_Logo.svg",
      },
    ],
  },
  "Back-End": {
    title: "Back-End Development",
    description:
      "Robust back-end solutions using Node.js, Express.js, MongoDB, PostgreSQL, Docker, and Redis.",
    techs: [
      {
        name: "Node.js",
        src: "https://upload.wikimedia.org/wikipedia/commons/d/d9/Node.js_logo.svg",
      },
      {
        name: "Express.js",
        src: "https://upload.wikimedia.org/wikipedia/commons/6/64/Expressjs.png",
      },
      {
        name: "MongoDB",
        src: "https://upload.wikimedia.org/wikipedia/commons/9/93/MongoDB_Logo.svg",
      },
      {
        name: "PostgreSQL",
        src: "https://upload.wikimedia.org/wikipedia/commons/2/29/Postgresql_elephant.svg",
      },
      {
        name: "Docker",
        src: "https://upload.wikimedia.org/wikipedia/commons/4/4e/Docker_%28container_engine%29_logo.svg",
      },
      {
        name: "Redis",
        src: "https://cdn.worldvectorlogo.com/logos/redis.svg",
      },
    ],
  },
  "Dev&CloudOps": {
    title: "DevOps & CloudOps",
    description:
      "Streamline development with Docker, Kubernetes, AWS, Azure, Terraform, and GitLab CI/CD.",
    techs: [
      {
        name: "Docker",
        src: "https://upload.wikimedia.org/wikipedia/commons/4/4e/Docker_%28container_engine%29_logo.svg",
      },
      {
        name: "Kubernetes",
        src: "https://upload.wikimedia.org/wikipedia/commons/3/39/Kubernetes_logo_without_workmark.svg",
      },
      {
        name: "AWS",
        src: "https://upload.wikimedia.org/wikipedia/commons/9/93/Amazon_Web_Services_Logo.svg",
      },
      {
        name: "Azure",
        src: "https://upload.wikimedia.org/wikipedia/commons/f/fa/Microsoft_Azure.svg",
      },
      {
        name: "Terraform",
        src: "https://cdn.jsdelivr.net/gh/hashicorp/terraform-website/assets/images/mark-7b39e57f.svg",
      },
      {
        name: "GitLab CI/CD",
        src: "https://upload.wikimedia.org/wikipedia/commons/1/1a/GitLab_CI_CD_Logo.svg",
      },
    ],
  },
  "AI/ML": {
    title: "AI & Machine Learning",
    description:
      "Advanced AI/ML solutions using TensorFlow, PyTorch, Keras, Scikit-Learn, OpenAI, and Hugging Face.",
    techs: [
      {
        name: "TensorFlow",
        src: "https://upload.wikimedia.org/wikipedia/commons/2/2d/Tensorflow_logo.svg",
      },
      {
        name: "PyTorch",
        src: "https://upload.wikimedia.org/wikipedia/commons/1/10/PyTorch_logo_icon.svg",
      },
      {
        name: "Keras",
        src: "https://upload.wikimedia.org/wikipedia/commons/a/ae/Keras_logo.svg",
      },
      {
        name: "Scikit-Learn",
        src: "https://upload.wikimedia.org/wikipedia/commons/0/05/Scikit_learn_logo_small.svg",
      },
      { name: "OpenAI", src: "https://openai.com/favicon.ico" },
      {
        name: "Hugging Face",
        src: "https://huggingface.co/front/assets/huggingface_logo-noborder.svg",
      },
    ],
  },
  "UI/UX": {
    title: "UI/UX Design",
    description:
      "Intuitive designs using Figma, Sketch, Adobe XD, InVision, and Balsamiq.",
    techs: [
      {
        name: "Figma",
        src: "https://upload.wikimedia.org/wikipedia/commons/3/33/Figma-logo.svg",
      },
      {
        name: "Sketch",
        src: "https://upload.wikimedia.org/wikipedia/commons/5/59/Sketch_Logo.svg",
      },
      {
        name: "Adobe XD",
        src: "https://upload.wikimedia.org/wikipedia/commons/c/c2/Adobe_XD_CC_icon.svg",
      },
      {
        name: "InVision",
        src: "https://www.invisionapp.com/assets/images/favicons/favicon-32x32.png",
      },
      { name: "Balsamiq", src: "https://balsamiq.com/assets/favicon-32x32.png" },
    ],
  },
  "QA&Testing": {
    title: "QA & Testing",
    description:
      "Ensure quality with Selenium, Jest, JUnit, Cypress, Postman, and Jira.",
    techs: [
      {
        name: "Selenium",
        src: "https://upload.wikimedia.org/wikipedia/commons/d/d5/Selenium_Logo.png",
      },
      { name: "Jest", src: "https://jestjs.io/img/jest.png" },
      {
        name: "JUnit",
        src: "https://junit.org/junit5/assets/img/junit5-banner.png",
      },
      {
        name: "Cypress",
        src: "https://docs.cypress.io/img/logos/cypress-logo-dark.png",
      },
      {
        name: "Postman",
        src: "https://www.svgrepo.com/show/354202/postman-icon.svg",
      },
      {
        name: "Jira",
        src: "https://seeklogo.com/images/J/jira-logo-8B72A6E9D7-seeklogo.com.png",
      },
    ],
  },
  Blockchain: {
    title: "Blockchain Development",
    description:
      "Secure blockchain solutions using Ethereum, Solidity, Hyperledger, Polkadot, Chainlink, and Truffle.",
    techs: [
      {
        name: "Ethereum",
        src: "https://upload.wikimedia.org/wikipedia/commons/6/6f/Ethereum-logo.png",
      },
      { name: "Solidity", src: "https://soliditylang.org/images/logo.svg" },
      {
        name: "Hyperledger",
        src: "https://www.hyperledger.org/wp-content/uploads/2017/07/HL_logo_color.svg",
      },
      {
        name: "Polkadot",
        src: "https://polkadot.network/assets/img/brand/Polkadot_Logo_Horizontal_Pink-Black.svg",
      },
      {
        name: "Chainlink",
        src: "https://chain.link/assets/images/brand/chainlink-logo.svg",
      },
      {
        name: "Truffle",
        src: "https://trufflesuite.com/img/truffle-logo-dark.svg",
      },
    ],
  },
};

export default function TechnologiesSection() {
  const [selectedTab, setSelectedTab] = useState<TabType>("Mobile");
  const [rating, setRating] = useState<number>(4.9);
  const [reviews, setReviews] = useState<number>(127);

  useEffect(() => {
    async function fetchGoogleRating() {
      try {
        const res = await fetch("/api/google-rating");
        if (!res.ok) throw new Error("Failed to fetch");
        const data = await res.json();
        setRating(data.rating || 4.9);
        setReviews(data.user_ratings_total || 127);
      } catch (error) {
        console.error("Error fetching Google rating:", error);
      }
    }
    fetchGoogleRating();
  }, []);

  const renderStars = (value: number): JSX.Element[] => {
    return Array.from({ length: 5 }, (_, i) => {
      const starIndex = i + 1;
      if (starIndex <= Math.floor(value)) {
        return <FaStar key={i} className="text-yellow-400" aria-hidden="true" />;
      }
      if (starIndex - 0.5 <= value) {
        return <FaStarHalfAlt key={i} className="text-yellow-400" aria-hidden="true" />;
      }
      return <FaStar key={i} className="text-gray-300" aria-hidden="true" />;
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      {/* Top Stats Bar */}
      <div className="w-full bg-blue-600 pl-15 grid grid-cols-2 sm:grid-cols-5 gap-6 py-10 px-6 text-white shadow-lg">
        {/* Google Reviews */}
        <a
          href="https://www.google.com/search?q=netroots-technologies#lrd=0x391904ca330f14f1:0x846bea0ccc4efab6,1,,,,"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center rounded-sm bg-amber-50 space-x-4 border-r border-white pr-6 last:border-r-0 col-span-2 sm:col-span-1 hover:opacity-90 transition"
          aria-label={`Google Reviews: ${rating.toFixed(1)} stars from ${reviews} reviews`}
        >
          <img
            src="google.png"
            alt="Google"
            className="w-14 h-14"
            loading="lazy"
          />
          <div className="text-left text-black">
            <div className="flex items-center space-x-2">
              <span className="text-2xl font-semibold">{rating.toFixed(1)}</span>
              <div className="flex">{renderStars(rating)}</div>
            </div>
            <p className="text-sm  mt-1">{reviews.toLocaleString()} Reviews</p>
          </div>
        </a>

        <div className="flex flex-col justify-center border-r border-white pr-6 last:border-r-0">
          <p className="text-3xl font-bold">
            40% <span className="text-xl">Boost</span>
          </p>
          <p className="text-sm">In website traffic within 6 months</p>
        </div>

        <div className="flex flex-col justify-center border-r border-white pr-6 last:border-r-0">
          <p className="text-3xl font-bold">98%</p>
          <p className="text-sm">Customer Satisfaction</p>
        </div>

        <div className="flex flex-col justify-center border-r border-white pr-6 last:border-r-0">
          <p className="text-3xl font-bold">
            100+ <span className="text-xl">Projects</span>
          </p>
          <p className="text-sm">Completed Successfully</p>
        </div>

        <div className="flex flex-col justify-center">
          <p className="text-3xl font-bold">24/7</p>
          <p className="text-sm">Support Available</p>
        </div>
      </div>

      {/* Technologies Section */}
        <section className="w-full h-auto min-h-[220px] bg-white py-12 px-6 sm:py-20">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-8 lg:gap-12 relative">
            {/* Mobile: Image at the top | Desktop: Image on the left */}
            <div className="w-full lg:w-1/2 flex justify-center order-1 lg:order-1">
            <img
                src="/tech.png"
                alt="Technology Illustration"
                className="w-full h-auto max-w-xs sm:max-w-md lg:mt-20 lg:h-[520px] object-contain"
                loading="lazy"
            />
            </div>

            {/* Right Section: Heading + Description + Tabs */}
            <div className="w-full lg:w-1/2 max-w-xl mx-auto lg:mx-0 order-2 lg:order-2">
            {/* Label */}
            <p className="text-sm font-semibold mb-2">
                <span className="text-teal-500">//</span> Tools & Technologies
            </p>

            {/* Heading */}
            <h2 className="text-3xl sm:text-4xl font-semibold text-black mb-4 leading-tight">
                We Offer Solutions Powered <br /> by These{" "}
                <span className="text-blue-600">Technologies</span>
            </h2>

            {/* Description */}
            <p className="text-gray-700 mb-6 text-sm sm:text-base leading-relaxed">
                Our company harnesses the power of cutting-edge technologies and
                frameworks to deliver innovative software solutions that meet the
                unique needs of our clients.
            </p>

            {/* Tabs buttons - Scrollable on mobile */}
            <div className="flex flex-wrap gap-2 mb-6 overflow-x-auto whitespace-nowrap scrollbar-hide pb-2 -mx-1 px-1">
                {tabs.map((tab) => {
                const isSelected = selectedTab === tab;
                return (
                    <button
                    key={tab}
                    onClick={() => setSelectedTab(tab)}
                    className={`px-4 py-1.5 border-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all duration-300 min-w-fit
                        ${
                        isSelected
                            ? "border-blue-600 text-blue-600 shadow-lg bg-blue-50"
                            : "border-gray-300 text-gray-700 hover:border-blue-600 hover:text-blue-600 hover:shadow-lg"
                        }
                        transform hover:-translate-y-0.5 active:scale-95 focus:outline-none focus:ring-2 focus:ring-blue-500
                    `}
                    >
                    {tab.replace(/&/g, " & ")}
                    </button>
                );
                })}
            </div>

            {/* Selected tab detail box */}
            <div className="border border-blue-400 rounded-xl p-5 sm:p-6 bg-white shadow-md">
                <h3 className="text-xl sm:text-2xl font-semibold text-blue-700 mb-3">
                {tabContent[selectedTab].title}
                </h3>
                <p className="text-gray-700 mb-5 text-sm sm:text-base">
                {tabContent[selectedTab].description}
                </p>
                <div className="grid grid-cols-2 gap-4 sm:gap-6">
                {tabContent[selectedTab].techs.map((tech) => (
                    <div
                    key={tech.name}
                    className="flex items-center space-x-2 sm:space-x-3 text-blue-600"
                    >
                    <img
                        src={tech.src}
                        alt={`${tech.name} logo`}
                        loading="lazy"
                        className="w-10 h-10 sm:w-12 sm:h-12 object-contain flex-shrink-0"
                        onError={(e) => {
                        e.currentTarget.src = `https://via.placeholder.com/48?text=${encodeURIComponent(
                            tech.name
                        )}`;
                        }}
                    />
                    <span className="font-semibold text-sm sm:text-base truncate">
                        {tech.name}
                    </span>
                    </div>
                ))}
                </div>
            </div>
            </div>
        </div>

        {/* Hide scrollbar but keep functionality */}
        <style jsx>{`
            .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
            }
            .scrollbar-hide::-webkit-scrollbar {
            display: none;
            }
        `}</style>
        </section>
    </div>
  );
}