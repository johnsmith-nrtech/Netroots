"use client"; 
import { useState } from "react";

const BENEFITS = [
  "Client-oriented",
  "Independent",
  "Competent",
  "Results-driven",
  "Problem-solving",
  "Transparent",
];

const STEPS = [
  "We schedule a call at your convenience",
  "We do a discovery and consulting meeting",
  "We prepare a proposal",
];

// BenefitItem Component
function BenefitItem({ text }) {
  return (
    <div className="flex items-center space-x-2" aria-label={`Benefit: ${text}`}>
      <span className="text-blue-500 font-bold" aria-hidden="true">
        ✔
      </span>
      <span>{text}</span>
    </div>
  );
}

// StepsList Component
function StepsList() {
  return (
    <div className="mt-8 text-sm" aria-label="Next steps">
      <p className="font-semibold mb-2">What happens next?</p>
      <ol className="list-decimal list-inside space-y-1">
        {STEPS.map((step, idx) => (
          <li key={idx}>{step}</li>
        ))}
      </ol>
    </div>
  );
}

export default function Home() {
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    company: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });

  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle"); // idle, submitting, success, error

  // Validate form inputs
  const validate = () => {
    const newErrors = {};
    if (!form.firstName.trim()) newErrors.firstName = "First name is required";
    if (!form.lastName.trim()) newErrors.lastName = "Last name is required";
    if (!form.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      newErrors.email = "Email is invalid";
    }
    if (!form.service) newErrors.service = "Please select a service";
    return newErrors;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }

    setErrors({});
    setStatus("submitting");

    try {
      // Simulated API call
      await new Promise((resolve) => setTimeout(resolve, 1500));

      setForm({
        firstName: "",
        lastName: "",
        company: "",
        email: "",
        phone: "",
        service: "",
        message: "",
      });

      setStatus("success");
    } catch (error) {
      setStatus("error");
    }
  };

  return (
    <div className="min-h-screen bg-[#e3e9f8] text-gray-900">
     

      {/* Row 1: Hero Section */}
      
      <div
        className="bg-[#0e0e13] w-full h-96 text-white px-6 py-20 md:px-16 text-center"
        role="banner"
      >
        <h1 className="text-xl text-left md:text-5xl font-bold max-w-7xl ml-4 grid md:grid-cols-2 gap-12">
          Partner with Us for Comprehensive IT and Digital Marketing Solutions
        </h1>
        
      </div>

      

      {/* Row 2: Content (2 Columns) */}
      <main className="px-6 md:px-16 py-16 max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Left Column */}
        <section>
          <p className="mb-4 text-lg max-w-xl leading-relaxed">
            Get in touch and let’s start crafting solutions that drive your business forward.
          </p>

          <p className="mb-6 text-sm max-w-xl">
            <strong>Your benefits:</strong>
            <br />
            Email us at:{" "}
            <a
              href="mailto:business@netrootstech.com"
              className="underline text-blue-600 hover:text-blue-800"
            >
              business@netrootstech.com
            </a>
          </p>

          {/* Benefits */}
          <div
            className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-10 text-sm max-w-xl"
            role="list"
          >
            {BENEFITS.map((item, idx) => (
              <BenefitItem key={idx} text={item} />
            ))}
          </div>

          {/* Steps */}
          <StepsList />
        </section>

        {/* Right Column */}
        <section>
         <div className="bg-white shadow-xl mt-0 md:-mt-100 rounded-lg p-8">

            <h2 className="text-2xl font-semibold mb-6 text-center">
              Schedule a Free Consultation{" "}
              <span className="text-green-600" aria-hidden="true">
                ✔
              </span>
            </h2>

            {/* Consultation Form */}
            <form
              onSubmit={handleSubmit}
              noValidate
              aria-live="polite"
              className="space-y-5"
            >
              <div className="flex gap-4">
                {/* First Name */}
                <div className="flex flex-col w-1/2">
                  <label htmlFor="firstName" className="mb-1 font-medium">
                    First Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="firstName"
                    name="firstName"
                    type="text"
                    placeholder="First name"
                    className={`px-4 py-2 border rounded focus:outline-none focus:ring-2 ${
                      errors.firstName
                        ? "border-red-500 focus:ring-red-500"
                        : "border-gray-300 focus:ring-blue-500"
                    }`}
                    value={form.firstName}
                    onChange={handleChange}
                    aria-invalid={errors.firstName ? "true" : "false"}
                    aria-describedby={
                      errors.firstName ? "firstName-error" : undefined
                    }
                  />
                  {errors.firstName && (
                    <span
                      id="firstName-error"
                      className="text-red-500 text-sm mt-1"
                    >
                      {errors.firstName}
                    </span>
                  )}
                </div>

                {/* Last Name */}
                <div className="flex flex-col w-1/2">
                  <label htmlFor="lastName" className="mb-1 font-medium">
                    Last Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="lastName"
                    name="lastName"
                    type="text"
                    placeholder="Last name"
                    className={`px-4 py-2 border rounded focus:outline-none focus:ring-2 ${
                      errors.lastName
                        ? "border-red-500 focus:ring-red-500"
                        : "border-gray-300 focus:ring-blue-500"
                    }`}
                    value={form.lastName}
                    onChange={handleChange}
                    aria-invalid={errors.lastName ? "true" : "false"}
                    aria-describedby={
                      errors.lastName ? "lastName-error" : undefined
                    }
                  />
                  {errors.lastName && (
                    <span
                      id="lastName-error"
                      className="text-red-500 text-sm mt-1"
                    >
                      {errors.lastName}
                    </span>
                  )}
                </div>
              </div>

              {/* Company */}
              <div className="flex flex-col">
                <label htmlFor="company" className="mb-1 font-medium">
                  Company / Organization / Startup
                </label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  placeholder="Company / Organization / Startup"
                  className="px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={form.company}
                  onChange={handleChange}
                />
              </div>

              {/* Email */}
              <div className="flex flex-col">
                <label htmlFor="email" className="mb-1 font-medium">
                  Email <span className="text-red-500">*</span>
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="Email"
                  className={`px-4 py-2 border rounded focus:outline-none focus:ring-2 ${
                    errors.email
                      ? "border-red-500 focus:ring-red-500"
                      : "border-gray-300 focus:ring-blue-500"
                  }`}
                  value={form.email}
                  onChange={handleChange}
                  aria-invalid={errors.email ? "true" : "false"}
                  aria-describedby={errors.email ? "email-error" : undefined}
                />
                {errors.email && (
                  <span id="email-error" className="text-red-500 text-sm mt-1">
                    {errors.email}
                  </span>
                )}
              </div>

              {/* Phone */}
              <div className="flex flex-col">
                <label htmlFor="phone" className="mb-1 font-medium">
                  Phone
                </label>
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  placeholder="Phone"
                  className="px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={form.phone}
                  onChange={handleChange}
                />
              </div>

              {/* Service */}
              <div className="flex flex-col">
                <label htmlFor="service" className="mb-1 font-medium">
                  How Can We Help You? <span className="text-red-500">*</span>
                </label>
                <select
                  id="service"
                  name="service"
                  className={`px-4 py-2 border rounded focus:outline-none focus:ring-2 ${
                    errors.service
                      ? "border-red-500 focus:ring-red-500"
                      : "border-gray-300 focus:ring-blue-500"
                  }`}
                  value={form.service}
                  onChange={handleChange}
                  aria-invalid={errors.service ? "true" : "false"}
                  aria-describedby={
                    errors.service ? "service-error" : undefined
                  }
                >
                  <option value="">Select a service</option>
                  <option value="it-services">IT Services</option>
                  <option value="digital-marketing">Digital Marketing</option>
                  <option value="web-development">Web Development</option>
                  <option value="seo">SEO</option>
                </select>
                {errors.service && (
                  <span
                    id="service-error"
                    className="text-red-500 text-sm mt-1"
                  >
                    {errors.service}
                  </span>
                )}
              </div>

              {/* Message */}
              <div className="flex flex-col">
                <label htmlFor="message" className="mb-1 font-medium">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows="4"
                  placeholder="To better assist you, please describe how we can help..."
                  className="px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  value={form.message}
                  onChange={handleChange}
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className={`w-full py-3 rounded font-semibold text-white transition ${
                  status === "submitting"
                    ? "bg-blue-400 cursor-not-allowed"
                    : "bg-blue-600 hover:bg-blue-700"
                }`}
                disabled={status === "submitting"}
                aria-busy={status === "submitting"}
              >
                {status === "submitting" ? "Submitting..." : "Submit"}
              </button>

              {/* Form Status Messages */}
              {status === "success" && (
                <p
                  className="mt-4 text-green-600 font-semibold text-center"
                  role="alert"
                >
                  Thank you! Your consultation request has been received.
                </p>
              )}
              {status === "error" && (
                <p
                  className="mt-4 text-red-600 font-semibold text-center"
                  role="alert"
                >
                  Oops! Something went wrong. Please try again later.
                </p>
              )}
            </form>
          </div>
        </section>
      </main>
    </div>
  );
}
